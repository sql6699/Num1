package com.test.listener;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
public class CountListener implements HttpSessionListener{
	private static long linedNumber=0;//初始化在线人数变量
	/*ServletContext application = null;
	public void contextDestroyed(ServletContextEvent event) {
		System.out.println("服务器关闭");
	}
	public void contextInitialized(ServletContextEvent event) {		
		List<String> list = new ArrayList<String>();	
		//用来保存所有已登录的用户	
		application =  event.getServletContext();	
		//取得application对象	
		application.setAttribute("allUser", list);	
		//将集合设置到application范围属性中去		
		}

	public void attributeAdded(HttpSessionBindingEvent se) {
	List<String> list = (List<String>)application.getAttribute("allUser");		
	//假设：用户登陆成功之后，只将户名设置到session中		
	String userName = (String)se.getValue();	
	//取得用户名		
	if(list.indexOf(userName) == -1){
		//表示此用户之前没有登陆	
		list.add(userName);	
		application.setAttribute("allUser", list);	
		}
	}
	public void attributeRemoved(HttpSessionBindingEvent se) {	
		List<String> list = (List<String>)application.getAttribute("allUser");	
		list.remove((String)se.getValue());		
		application.setAttribute("allUser", list);	
		}

	public void sessionCreated(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	public void sessionDestroyed(HttpSessionEvent arg0) {
		// TODO Auto-generated method stub
		
	}*/
	

	//监听session创建的方法
	public void sessionCreated(HttpSessionEvent arg0) {
		linedNumber++;
	}
	////监听session销毁的方法
	public void sessionDestroyed(HttpSessionEvent arg0) {
		linedNumber--;
	}
	//返回在线人数
	public static long getLinedNumber(){
		return linedNumber;
	}

}
