package com.test.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.pojo.Admin;
import com.test.pojo.User;
import com.test.service.AdminService;

import com.test.service.impl.AdminServiceImpl;


public class AdminFilter implements Filter {
	private AdminService adminService = new AdminServiceImpl();
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		
		if(user != null){
			System.out.println("userType:"+user.getUserType());
			if (user.getUserType() != 0) {
				
				session.setAttribute("message", "对不起，只有管理员才可以访问");
				res.sendRedirect(req.getContextPath() + "/index.jsp");
			} else {
				chain.doFilter(req, res);
			}
		}else{
			session.setAttribute("message", "对不起，请先登录！");
			res.sendRedirect(req.getContextPath() + "/login.jsp");
		}
		
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
