package com.test.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.pojo.User;

public class LoginFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");

		//request.getRequestURI() 返回除去host（域名或者ip）部分的路径
		String uri = req.getRequestURI();
		System.out.println("LoginFilter中的user：" + user);
		System.out.println("地址" + uri);
		if (user != null || uri.contains("login.jsp")
				|| uri.contains("LoginServlet")
				|| uri.equals("/studentManager/") || uri.endsWith(".js")
				|| uri.endsWith(".css") || uri.endsWith(".gif")
				|| uri.endsWith(".jpg")) {
			System.out.println("过滤器 完成 ：LoginFilter" + req.getRequestURI());
			chain.doFilter(req, res);
		} else {
			System.out.println("过滤器 没有user ：LoginFilter" + req.getRequestURI());
			session.setAttribute("message", "对不起，只有登陆后才能访问系统！");
			res.sendRedirect(req.getContextPath() + "/login.jsp");
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
