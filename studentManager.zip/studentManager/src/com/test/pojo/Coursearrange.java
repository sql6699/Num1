


package com.test.pojo;

import com.test.dao.ClasstabDao;
import com.test.dao.CourseDao;
import com.test.dao.TeacherDao;
import com.test.dao.impl.ClasstabDaoImpl;
import com.test.dao.impl.CourseDaoImpl;
import com.test.dao.impl.TeacherDaoImpl;

public class Coursearrange {
	private String cou_id;
	private Course course;
	private Classtab classtbl;
	private Teacher teacher;
	
	//private Teacher teacher;
	private String cou_room;
	
	private CourseDao courseDao = new CourseDaoImpl();
	private ClasstabDao classtabDao = new ClasstabDaoImpl();
	private TeacherDao teacherDao = new TeacherDaoImpl();
	
	
	public Coursearrange(){}


	public String getCou_id() {
		return cou_id;
	}


	public void setCou_id(String cou_id) {
		this.cou_id = cou_id;
	}


	public Teacher getTeacher() {
		return teacher;
	}


	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}


	public String getCou_room() {
		return cou_room;
	}


	public void setCou_room(String cou_room) {
		this.cou_room = cou_room;
	}


	public Course getCourse() {
		return course;
	}


	public void setCourse(Course course) {
		this.course = course;
	}


	public Classtab getClasstbl() {
		return classtbl;
	}


	public void setClasstbl(Classtab classtbl) {
		this.classtbl = classtbl;
	}

	public void setCou_coid(String cou_coid){
		this.setCourse(courseDao.findCourseByid(cou_coid));
		//************
//		this.course = courseDao.findCourseByid(co_id);
	}
	
	public void setCou_clid(String cou_clid) {
		//this.setClasstbl(classDao.findClasstblById(classNo));
		this.setClasstbl(classtabDao.findClassByid(cou_clid));
		//*************
		
	}

	public void setCou_tid(String cou_tid){
		this.setTeacher(teacherDao.findTeacherByid(cou_tid));
		//************
		
	}


	public Coursearrange(String cou_id, Course course, Classtab classtbl,
			Teacher teacher, String cou_room, CourseDao courseDao,
			ClasstabDao classtabDao, TeacherDao teacherDao) {
		super();
		this.cou_id = cou_id;
		this.course = course;
		this.classtbl = classtbl;
		this.teacher = teacher;
		this.cou_room = cou_room;
		this.courseDao = courseDao;
		this.classtabDao = classtabDao;
		this.teacherDao = teacherDao;
	}


	@Override
	public String toString() {
		return "Coursearrange [cou_id=" + cou_id + ", course=" + course
				+ ", classtbl=" + classtbl + ", teacher=" + teacher
				+ ", cou_room=" + cou_room + ", courseDao=" + courseDao
				+ ", classtabDao=" + classtabDao + ", teacherDao=" + teacherDao
				+ "]";
	}
	
}
