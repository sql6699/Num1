package com.test.pojo;

import com.test.dao.CourseDao;
import com.test.dao.CoursearrangeDao;
import com.test.dao.StudentDao;
import com.test.dao.impl.CourseDaoImpl;
import com.test.dao.impl.CoursearrangeDaoImpl;
import com.test.dao.impl.StudentDaoImpl;

public class Grade {

	private String id;
	private Student student;
	private Coursearrange arrange;
	
	private String grade;
	
	private String note;

	//private CourseDao courseDao = new CourseDaoImpl();
	private CoursearrangeDao coursearrangeDao = new CoursearrangeDaoImpl();
	private StudentDao studentDao = new StudentDaoImpl();
	
	public void setStuid(String stuid){
		//this.student = studentDao.findStudentByid(stuid);
		this.student = studentDao.findStudentByid(stuid);
	}
	
	public void setArrangeid(String arrangeid){
		this.arrange =coursearrangeDao.findarrangeByid(arrangeid);
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Coursearrange getArrange() {
		return arrange;
	}

	public void setArrange(Coursearrange arrange) {
		this.arrange = arrange;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Grade(String id, Student student, Coursearrange arrange,
			String grade, String note) {
		super();
		this.id = id;
		this.student = student;
		this.arrange = arrange;
		this.grade = grade;
		this.note = note;
	}

	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Grade [id=" + id + ", student=" + student + ", arrange="
				+ arrange + ", grade=" + grade + ", note=" + note
				+ ", coursearrangeDao=" + coursearrangeDao + ", studentDao="
				+ studentDao + "]";
	}
	
	
	
	
	
	
	
}
