package com.test.pojo;

public class Classtab {
	
	private int cl_id;			//班级编号
	private String cl_name;		//班级名称
	private String cl_belong;	//所属学院
	
	//get和set方法
	public int getCl_id() {
		return cl_id;
	}
	public void setCl_id(int cl_id) {
		this.cl_id = cl_id;
	}
	public String getCl_name() {
		return cl_name;
	}
	public void setCl_name(String cl_name) {
		this.cl_name = cl_name;
	}
	public String getCl_belong() {
		return cl_belong;
	}
	public void setCl_belong(String cl_belong) {
		this.cl_belong = cl_belong;
	}
	
	//无参构造器
	public Classtab() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//有参构造器
	public Classtab(int cl_id, String cl_name, String cl_belong) {
		super();
		this.cl_id = cl_id;
		this.cl_name = cl_name;
		this.cl_belong = cl_belong;
	}
	
	@Override
	public String toString() {
		return "Classtab [cl_id=" + cl_id + ", cl_name=" + cl_name
				+ ", cl_belong=" + cl_belong + "]";
	}
	
}
