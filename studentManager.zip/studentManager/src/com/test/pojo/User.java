package com.test.pojo;

public class User {

	private int userType;// 用户类型listener
	private String name;// 用户名listener:admin;student;teacher
	private String logname;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserType() {
		return userType;
	}
	public void setUserType(int userType) {
		this.userType = userType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogname() {
		return logname;
	}
	public void setLogname(String logname) {
		this.logname = logname;
	}
	public User(int userType, String name, String logname) {
		super();
		this.userType = userType;
		this.name = name;
		this.logname = logname;
	}
	@Override
	public String toString() {
		return "User [userType=" + userType + ", name=" + name + ", logname=" + logname + "]";
	}
	
	
	

	
}
