package com.test.pojo;

import com.test.dao.ClasstabDao;
import com.test.dao.impl.ClasstabDaoImpl;

public class Student {
	

	private ClasstabDao classtabDao = new ClasstabDaoImpl();
	
	private int st_id;      // 学生编号
	private String st_name;    // 学生姓名
	private String st_pwd;     // 登录密码	
	private String st_tel;     // 电话
	private String st_adress;  // 住址
	private String st_email;   // 邮箱
	//private String st_classid; // 所在班级
	private Classtab classtab;  //这是一个classtab的对象

	public Student() {
	}
	public int getSt_id() {
		return this.st_id;
	}

	public void setSt_id(int st_id) {
		this.st_id = st_id;
	}

	public String getSt_name() {
		return this.st_name;
	}

	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}
	public String getSt_pwd() {
		return this.st_pwd;
	}

	public void setSt_pwd(String st_pwd) {
		this.st_pwd = st_pwd;
	}
			
	public String getSt_tel() {
		return this.st_tel;
	}

	public void setSt_tel(String st_tel) {
		this.st_tel = st_tel;
	}
	
	public String getSt_adress() {
		return this.st_adress;
	}

	public void setSt_adress(String st_adress) {
		this.st_adress = st_adress;
	}
	public String getSt_email() {
		return this.st_email;
	}

	public void setSt_email(String st_email) {
		this.st_email = st_email;
	}
	
	public Classtab getClasstab() {
		return classtab;
	}
	
	public void setSt_classid(String st_classid) {
		this.classtab = classtabDao.findClassByid(st_classid);
		//classtabDao.queryClasstab(st_classid);
	}
	
	@Override
	public String toString() {
		return "Student [st_id=" + st_id + ", st_name=" + st_name + ", st_pwd="
				+ st_pwd + ", st_tel=" + st_tel + ", st_adress=" + st_adress
				+ ", st_email=" + st_email + ", st_classid=" + classtab.getCl_id() + "]";
	}

	
	
	
	
}
