package com.test.pojo;

public class Course {
	
	private String co_id;		//编号
	private String co_name;		//名称
	private int co_period;		//学时
	private int co_credits;		//学分
	private String co_type;		//课程类别
	private String co_term;		//学期
	
	public String getCo_id() {
		return co_id;
	}
	public void setCo_id(String co_id) {
		this.co_id = co_id;
	}
	public String getCo_name() {
		return co_name;
	}
	public void setCo_name(String co_name) {
		this.co_name = co_name;
	}
	public int getCo_period() {
		return co_period;
	}
	public void setCo_period(int co_period) {
		this.co_period = co_period;
	}
	public int getCo_credits() {
		return co_credits;
	}
	public void setCo_credits(int co_credits) {
		this.co_credits = co_credits;
	}
	public String getCo_type() {
		return co_type;
	}
	public void setCo_type(String co_type) {
		this.co_type = co_type;
	}
	public String getCo_term() {
		return co_term;
	}
	public void setCo_term(String co_term) {
		this.co_term = co_term;
	}
	
	//无参构造器
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//有参构造器
	public Course(String co_id, String co_name, int co_period, int co_credits,
			String co_type, String co_term) {
		super();
		this.co_id = co_id;
		this.co_name = co_name;
		this.co_period = co_period;
		this.co_credits = co_credits;
		this.co_type = co_type;
		this.co_term = co_term;
	}
	
	@Override
	public String toString() {
		return "Course [co_id=" + co_id + ", co_name=" + co_name
				+ ", co_period=" + co_period + ", co_credits=" + co_credits
				+ ", co_type=" + co_type + ", co_term=" + co_term + "]";
	}
	
}
