package com.test.pojo;

public class Admin {

	private String ad_logname;
	private String ad_name;
	private String ad_pwd;
	
	public String getAd_logname() {
		return ad_logname;
	}
	public void setAd_logname(String ad_logname) {
		this.ad_logname = ad_logname;
	}
	public String getAd_name() {
		return ad_name;
	}
	public void setAd_name(String ad_name) {
		this.ad_name = ad_name;
	}
	public String getAd_pwd() {
		return ad_pwd;
	}
	public void setAd_pwd(String ad_pwd) {
		this.ad_pwd = ad_pwd;
	}
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(String ad_logname, String ad_name, String ad_pwd) {
		super();
		this.ad_logname = ad_logname;
		this.ad_name = ad_name;
		this.ad_pwd = ad_pwd;
	}
	@Override
	public String toString() {
		return "Admin [ad_logname=" + ad_logname + ", ad_name=" + ad_name + ", ad_pwd=" + ad_pwd + "]";
	}
	
}
