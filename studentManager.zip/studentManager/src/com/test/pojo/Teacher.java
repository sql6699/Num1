package com.test.pojo;

public class Teacher {
	private int te_id;
	private String te_name;
	private String te_pwd;
	private String te_title;
	private String te_eduback;
	private String te_adress;
	private String te_tel;
	private String te_email;
	private String te_reserch;
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTe_id() {
		return te_id;
	}
	public void setTe_id(int te_id) {
		this.te_id = te_id;
	}
	public String getTe_name() {
		return te_name;
	}
	public void setTe_name(String te_name) {
		this.te_name = te_name;
	}
	public String getTe_pwd() {
		return te_pwd;
	}
	public void setTe_pwd(String te_pwd) {
		this.te_pwd = te_pwd;
	}
	public String getTe_title() {
		return te_title;
	}
	public void setTe_title(String te_title) {
		this.te_title = te_title;
	}
	public String getTe_eduback() {
		return te_eduback;
	}
	public void setTe_eduback(String te_eduback) {
		this.te_eduback = te_eduback;
	}
	public String getTe_adress() {
		return te_adress;
	}
	public void setTe_adress(String te_adress) {
		this.te_adress = te_adress;
	}
	public String getTe_tel() {
		return te_tel;
	}
	public void setTe_tel(String te_tel) {
		this.te_tel = te_tel;
	}
	public String getTe_email() {
		return te_email;
	}
	public void setTe_email(String te_email) {
		this.te_email = te_email;
	}
	public String getTe_reserch() {
		return te_reserch;
	}
	public void setTe_reserch(String te_reserch) {
		this.te_reserch = te_reserch;
	}
	public Teacher(int te_id, String te_name, String te_pwd, String te_title,
			String te_eduback, String te_adress, String te_tel,
			String te_email, String te_reserch) {
		super();
		this.te_id = te_id;
		this.te_name = te_name;
		this.te_pwd = te_pwd;
		this.te_title = te_title;
		this.te_eduback = te_eduback;
		this.te_adress = te_adress;
		this.te_tel = te_tel;
		this.te_email = te_email;
		this.te_reserch = te_reserch;
	}
	@Override
	public String toString() {
		return "Teacher [te_id=" + te_id + ", te_name=" + te_name + ", te_pwd="
				+ te_pwd + ", te_title=" + te_title + ", te_eduback="
				+ te_eduback + ", te_adress=" + te_adress + ", te_tel="
				+ te_tel + ", te_email=" + te_email + ", te_reserch="
				+ te_reserch + "]";
	}
	
	
	

}
