package com.test.dao;

import java.util.List;

import com.test.pojo.Admin;

public interface AdminDao {

	//添加管理员
	public void addAdmin(Admin admin);	
	
	//根据登录名密码得到一个管理员对象
	public Admin getAdmin(String ad_logname,String ad_pwd); 
	
	//查找所有的admini信息
	List findAllAdmin();	

	//根据登录名，名字，密码查询得到管理员
	public List findAdmin(String ad_logname,String ad_name,String ad_pwd);
	
	//修改信息
	public void updateAdmin(Admin admin);
	
	//根据ad_logname查询管理员信息
	public Admin findAdminByLoginName(String ad_logname);
	
	//根据ad_lognname删除管理员
	public void deleteAdminByLoginName(String ad_logname);
	
}
