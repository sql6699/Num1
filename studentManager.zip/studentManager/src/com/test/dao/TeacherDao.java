package com.test.dao;

import java.util.List;

import com.test.pojo.Student;
import com.test.pojo.Teacher;

public interface TeacherDao {
	//public Student findStudentByid(String st_id);public List findAllAdmin()

	public Teacher findTeacherByid(String te_id);
	public List findAllTeacher();
	
	public Teacher getTeacher(String te_id,String te_pwd);
}
