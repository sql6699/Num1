package com.test.dao;

import java.sql.SQLException;
import java.util.List;

import com.test.pojo.Classtab;
import com.test.pojo.Course;

//操作数据库

public interface ClasstabDao {

	public Classtab getClasstab(int cl_id,String cl_name,String cl_belong);
	
	//***********添加课程信息*************
	public void addclass(Classtab classtab);
	
	//***********删除课程信息*************
	public void deleteclass(int cl_id);
	
	//***********修改课程信息*************
	public int updateclass(Classtab classtab);
	
	//***********列表查询全部课程信息*************
	public List queryAllClasstab();
	
	//***********根据班级编号查询课程信息*************
	public Classtab queryClasstab(int cl_id);
	
	//public Course findCourseByid(String co_id)
	public Classtab findClassByid(String cl_id);//***
	
}
