package com.test.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.test.dao.CourseDao;
import com.test.pojo.Course;
import com.test.pojo.Student;
import com.test.utils.C3P0Utils;

public class CourseDaoImpl implements CourseDao {
	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());
	public Course getCourse(String co_id, String co_name, int co_period,
			int co_credits, String co_type, String co_term) {
		
		

		String sql = "select * from course where co_id=? and co_name=? and co_period=? and co_credits=? and co_type=? and co_term=?";
		Object[] params = new Object[] { co_id, co_name, co_period, co_credits,co_type,co_term};

		// 查询到返回一个对象；否则返回一个null
		Course course = null;
		try {
			course = (Course) queryRunner.query(sql, new BeanHandler(
					Course.class), params);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return course;
	}
	
	
	public List findAllCourse(){
		String sql = "select * from course";
		List<Course> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Course>(Course.class));
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	
	public Course findCourseByid(String co_id){
		int num = Integer.parseInt(co_id);
		String sql = "select * from course where co_id = ? ";
		Object[] params = new Object[] {num};
		Course course = null;
		try {
			course = queryRunner.query(sql, new BeanHandler(Course.class), params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return course;
	}
	
	
	/**
	 * public Student findStudentByid(String st_id) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(st_id);
		String sql = "select * from student where st_id = ? ";
		Object[] params = new Object[] {num};
		Student student = null;
		try {
			student = queryRunner.query(sql, new BeanHandler(Student.class),params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return student;
	}
	
	 */

}
