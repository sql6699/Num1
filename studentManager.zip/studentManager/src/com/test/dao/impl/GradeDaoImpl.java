package com.test.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import sun.net.www.content.image.gif;

import com.sun.org.apache.regexp.internal.recompile;
import com.test.dao.GradeDao;
import com.test.pojo.Admin;
import com.test.pojo.Coursearrange;
import com.test.pojo.Grade;
import com.test.utils.C3P0Utils;

public class GradeDaoImpl implements GradeDao{
	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());

	public void addGrade(Grade grade) {
		// TODO Auto-generated method stub
		String sql = "update grade set grade=?,note=? where id = ?";
		Object[] params = {grade.getGrade(),grade.getNote(),grade.getId()};
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	//**************************************************************************
	public void updataGradeByID(String id, String grade, String note) {
		// TODO Auto-generated method stub
		String sql = "update grade set grade=?,note=? where id = ?";
		Object[] params = {grade,note,id};
		try {
			int re = queryRunner.update(sql, params);
			System.out.println(re);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}


	public List findGrades(List<Coursearrange> arrange) {
		// TODO Auto-generated method stub

		if (arrange.isEmpty()) {
			return null;
			
		} else {
			String sql = "select * from grade ";
			boolean flage = false;
			for (Coursearrange coursearrange : arrange) {
				if (!flage) {
					sql += "where arrangeid = '" + coursearrange.getCou_id()+"'";
					System.err.println(sql);
					flage = true;
				} else {
					sql += "or arrangeid = '" + coursearrange.getCou_id()+"'";
				}
				
			}
			 
			List<Grade> list = null;
			try {
				list = queryRunner.query(sql, new BeanListHandler<Grade>(Grade.class));
			} catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			return list;
		}
	}

	public List<Grade> findGrades() {
		// TODO Auto-generated method stub
		String sql = "select * from grade";
		List<Grade> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Grade>(Grade.class));
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return list;
	}

	
	
}
