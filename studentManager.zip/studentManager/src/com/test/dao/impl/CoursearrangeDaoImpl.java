package com.test.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.test.dao.CourseDao;
import com.test.dao.CoursearrangeDao;
import com.test.pojo.Admin;
import com.test.pojo.Course;
import com.test.pojo.Coursearrange;
import com.test.pojo.Student;
import com.test.utils.C3P0Utils;

public class CoursearrangeDaoImpl implements CoursearrangeDao{
	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());

	
	//findAllCourseArranges();
	public List<Coursearrange> findCoursearranges(String cou_coid,
			String cou_clid) {
		// TODO Auto-generated method stub
		
		
		String sql = "select * from coursearrange";
		boolean flag = false;
		if (!cou_coid.isEmpty()) {
			sql += " where cou_coid='"+cou_coid+"'";
			flag = true;
			
		}
		
		if (!cou_clid.isEmpty()) {
			int a = Integer.parseInt(cou_clid);
			if (flag) {
				sql += " and cou_clid='"+a+"'";
			} else {
				sql += " where cou_clid ='"+a+"'";
			}
		}
		
		System.out.println(sql);
		List<Coursearrange> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Coursearrange>(Coursearrange.class));
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

	public Coursearrange findarrangeByid(String cou_id){
		String sql = "select * from coursearrange where cou_id = ? ";
		Object[] params = new Object[] {cou_id};
		Coursearrange coursearrange = null;
		try {
			coursearrange = queryRunner.query(sql, new BeanHandler(Coursearrange.class),params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return coursearrange;
		
	}
	
	public List<Coursearrange> findAllCourseArrange(String cou_id, String cou_coid, String cou_clid,String cou_tid){
		String sql = "select * from coursearrange";
		boolean flag = false;
		if (!cou_id.isEmpty()) {
			sql += " where cou_id='" + cou_id + "'";
			flag = true;
		}
		if (!cou_coid.isEmpty()) {
			if (flag) {
				//int i=Integer.parseInt(s);
				sql += " and cou_coid='" + cou_coid + "'";
			} else {
				sql += " where cou_coid='" + cou_coid + "'";
			}
			flag = true;
		}

		if (!cou_clid.isEmpty()) {
			int a = Integer.parseInt(cou_clid);
			if (flag) {
				sql += " and cou_clid='" + a + "'";
			} else {
				sql += " where cou_clid='" + a + "'";
			}
		}

		if (!cou_tid.isEmpty()) {
			int b = Integer.parseInt(cou_tid);
			if (flag) {
				sql += " and cou_tid='" + b + "'";
			} else {
				sql += " where cou_tid='" + b + "'";
			}
		}
		System.out.println(sql);
		List<Coursearrange> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Coursearrange>(Coursearrange.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	
	public List<Coursearrange> findAllCourseArranges() {
		String sql = "select * from coursearrange";
		List<Coursearrange> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Coursearrange>(Coursearrange.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}

	public void addCoursearrange(Coursearrange coursearrange) {
		// TODO Auto-generated method stub
		String sql = "insert into coursearrange(cou_id,cou_coid,cou_clid,cou_tid,cou_room) values(?,?,?,?,?)";
		Object[] params = new Object[] {coursearrange.getCou_id(),coursearrange.getCourse().getCo_id(),
				coursearrange.getClasstbl().getCl_id(),coursearrange.getTeacher().getTe_id(),coursearrange.getCou_room()};
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
	}
	
	
	public void updateCourseArrange(Coursearrange coursearrange) {
		// TODO Auto-generated method stub
		String sql = "update coursearrange set cou_coid=?,cou_clid=?,cou_tid=?,cou_room=? where cou_id=?";
		Object[] params = { coursearrange.getCourse().getCo_id(),
				coursearrange.getClasstbl().getCl_id(),coursearrange.getTeacher().getTe_id(),
				coursearrange.getCou_room(),coursearrange.getCou_id()};
		try {
			queryRunner.update(sql,params);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int deleteArrange(String cou_id){
		int re = -1;
		String sql = "delete from coursearrange where cou_id=?";
		try {
			queryRunner.update(sql, cou_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return re;
		
	}
	
}
