package com.test.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.test.dao.TeacherDao;
import com.test.pojo.Admin;
import com.test.pojo.Student;
import com.test.pojo.Teacher;
import com.test.utils.C3P0Utils;

public class TeacherDaoImpl implements TeacherDao{
	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());
	
	public Teacher findTeacherByid(String te_id) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(te_id);
		String sql = "select * from teacher where te_id = ? ";
		Object[] params = new Object[] {num};
		Teacher teacher = null;
		try {
			teacher=queryRunner.query(sql, new BeanHandler(Teacher.class), params);
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return teacher;
		
	}

	public List findAllTeacher() {
		// TODO Auto-generated method stub
		String sql = "select * from teacher";
		List<Teacher> list = null;
		try {
			list = queryRunner.query(sql,new BeanListHandler<Teacher>(Teacher.class));
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	
	/**
	 * 	public List findAllAdmin() {
		String sql = "select * from admin";
		List<Admin> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Admin>(
					Admin.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	
	 */
	public Teacher getTeacher(String te_id,String te_pwd) {
		int num = Integer.parseInt(te_id);
		String sql = "select * from teacher where teacherid = ? and password = ?";
		Object[] params = new Object[] { num, te_pwd };
		Teacher teacher = null;
		try {
			teacher = (Teacher) queryRunner.query(sql, new BeanHandler(Teacher.class), params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return teacher;
		
	}

}
