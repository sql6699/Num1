package com.test.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.test.dao.ClasstabDao;
import com.test.pojo.Classtab;
import com.test.pojo.Course;
import com.test.utils.C3P0Utils;

public class ClasstabDaoImpl implements ClasstabDao {

	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());

	/*
	 * QueryRunner中一共有6种方法：
	 * 
	 * execute（执行SQL语句） batch（批量处理语句） insert（执行INSERT语句）
	 * insertBatch（批量处理INSERT语句） query（SQL中 SELECT 语句） update（SQL中
	 * INSERT,UPDATE, 或 DELETE 语句）
	 */

	// ***********添加课程信息*************
	public void addclass(Classtab classtab) {
		String sql = "insert into class(cl_id,cl_name,cl_belong) values(?,?,?)";
		Object[] params = new Object[] { classtab.getCl_id(),classtab.getCl_name(), classtab.getCl_belong() };
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// ***********删除课程信息*************
	public void deleteclass(int cl_id) {
		String sql = "delete from class where cl_id=?";
		try {
			queryRunner.update(sql, cl_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// ***********修改课程信息*************
	public int updateclass(Classtab classtab){
		String sql = "update class set cl_name=? , cl_belong=? where cl_id=?";
		Object[] params = new Object[] {classtab.getCl_name(), classtab.getCl_belong(), classtab.getCl_id()};
		int result = 0;
		try {
			result = queryRunner.update(sql, params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	// ***********列表查询全部课程信息*************
	public List queryAllClasstab() {
		String sql = "select * from class";
		List<Classtab> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Classtab>(
					Classtab.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	// ***********根据班级编号查询课程信息*************
	public Classtab queryClasstab(int cl_id) {
		String sql = "select * from class where cl_id=?";
		Classtab classtab = null;
		try {
			classtab = queryRunner.query(sql, new BeanHandler(Classtab.class),
					cl_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return classtab;
	}

//测试可以没用到
	public Classtab getClasstab(int cl_id, String cl_name, String cl_belong) {

		QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());

		String sql = "select *from class where cl_id=? and cl_name=? and cl_belong=?";
		Object[] params = new Object[] { cl_id, cl_name, cl_belong };

		// 查询到返回一个对象；否则返回一个null
		Classtab classtab = null;
		try {
			classtab = (Classtab) queryRunner.query(sql, new BeanHandler(
					Classtab.class), params);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return classtab;
	}
	
	
	
	
	public Classtab findClassByid(String cl_id){
		
		int num = Integer.parseInt(cl_id);
		String sql = "select * from class where cl_id = ? ";
		Object[] params = new Object[] {num};
		Classtab classtab = null;
		try {
			classtab = queryRunner.query(sql, new BeanHandler(Classtab.class), params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return classtab;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 
	public Course findCourseByid(String co_id){
		int num = Integer.parseInt(co_id);
		String sql = "select * from course where coid = ? ";
		Object[] params = new Object[] {num};
		Course course = null;
		try {
			course = queryRunner.query(sql, new BeanHandler(Course.class), params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return course;
	}
	
	 */
	
	
	
	
	
	
}
