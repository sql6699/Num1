package com.test.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.test.dao.AdminDao;
import com.test.pojo.Admin;
import com.test.utils.C3P0Utils;

public class AdminDaoImpl implements AdminDao {

	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());
	
	/*
	 * QueryRunner中一共有6种方法：
	 * 
	 * execute（执行SQL语句） batch（批量处理语句） insert（执行INSERT语句）
	 * insertBatch（批量处理INSERT语句） query（SQL中 SELECT 语句） update（SQL中
	 * INSERT,UPDATE, 或 DELETE 语句）
	 */
	
	//添加管理员
	public void addAdmin(Admin admin) {
		String sql = "insert into admin(ad_logname,ad_name,ad_pwd) values(?,?,?)";
		Object[] params = new Object[] { admin.getAd_logname(), admin.getAd_name(),
				admin.getAd_pwd()};
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//得到一个管理员信息，进行登录时用
	public Admin getAdmin(String ad_logname, String ad_pwd) {
		String sql = "select * from admin where ad_logname=? and ad_pwd=?";
		Object[] params = new Object[] { ad_logname, ad_pwd };
		Admin admin = null;
		try {
			admin = (Admin)queryRunner.query(sql, new BeanHandler(Admin.class),params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admin;
	}

	//查找所有的admini信息
	public List findAllAdmin() {
		String sql = "select * from admin";
		List<Admin> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Admin>(
					Admin.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	//根据登录名，名字，密码查询得到管理员
	public List findAdmin(String ad_logname, String ad_name, String ad_pwd) {
		String sql = "select * from admin";
		boolean flag = false; // 已有where子句，则为true
		if (!ad_logname.isEmpty()) {
			//where ad_logname="ad_logname";
			sql += " where ad_logname='" + ad_logname + "'";
			flag = true;
		}
		if (!ad_name.isEmpty()) {
			if (flag) {
				sql += " and ad_name='" + ad_name + "'";
			} else {
				sql += " where ad_name='" + ad_name + "'";
			}
			flag = true;
		}
		if (!ad_pwd.isEmpty()) {
			if (flag) {
				sql += " and ad_pwd='" + ad_pwd + "'";
			} else {
				sql += " where ad_pwd='" + ad_pwd + "'";
			}
		}
		//select * from admin where ad_logname='褚波' and ad_name='chubo' and ad_pwd='123456'
		System.out.println(sql);
		List<Admin> list = null;
		try {
			list = queryRunner.query(sql, new BeanListHandler<Admin>(
					Admin.class));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	//根据登录名修改信息
	public void updateAdmin(Admin admin) {
		//注：根据什么字段修改其它值则该字段不能修改。注意格式！！！！！！
		String sql = "update admin set ad_name=?,ad_pwd=? where ad_logname = ?";
		Object[] params = { admin.getAd_name(), admin.getAd_pwd(),
				admin.getAd_logname()};
		try {
			queryRunner.update(sql, params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//根据ad_logname查询管理员信息
	public Admin findAdminByLoginName(String ad_logname) {
		String sql = "select * from admin where ad_logname = ? ";
		Object[] params = new Object[] { ad_logname };
		Admin admin = null;
		try {
			admin = (Admin) queryRunner.query(sql,
					new BeanHandler(Admin.class), params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admin;
	}

	public void deleteAdminByLoginName(String ad_logname) {
		String sql = "delete from admin where ad_logname =? ";
		try {
			queryRunner.update(sql, ad_logname);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
