package com.test.dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.test.dao.StudentDao;
import com.test.pojo.Admin;
import com.test.pojo.Student;
import com.test.utils.C3P0Utils;

public class StudentDaoImpl implements StudentDao{
	QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());

	public Student findStudentByid(String st_id) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(st_id);
		String sql = "select * from student where st_id = ? ";
		Object[] params = new Object[] {num};
		Student student = null;
		try {
			student = queryRunner.query(sql, new BeanHandler(Student.class),params);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return student;
	}
	
	public Student getStudent(String st_id, String st_pwd) {
		int num = Integer.parseInt(st_id);
		String sql = "select * from student where st_id = ? and st_pwd = ?";
		Object[] params = new Object[] { num, st_pwd };
		Student student = null;
		try {
			student = (Student) queryRunner.query(sql, new BeanHandler(
					Student.class), params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return student;
	}
	
	
	
	
	
	/**
	 * 	//根据ad_logname查询管理员信息
	public Admin findAdminByLoginName(String ad_logname) {
		String sql = "select * from admin where ad_logname = ? ";
		Object[] params = new Object[] { ad_logname };
		Admin admin = null;
		try {
			admin = (Admin) queryRunner.query(sql,
					new BeanHandler(Admin.class), params);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admin;
	}
	 */

}
