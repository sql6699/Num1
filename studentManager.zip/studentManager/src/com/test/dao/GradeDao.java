package com.test.dao;

import java.util.List;

import com.test.pojo.Admin;
import com.test.pojo.Coursearrange;
import com.test.pojo.Grade;

public interface GradeDao {
	
	//添加成绩信息
	public void addGrade(Grade grade);
	//public void addGrade(String id,String grade,String note);
	public List findGrades(List<Coursearrange> arrange);
	//public List<Coursearrange> findAllCourseArrange(String cou_id, String cou_coid, String cou_clid,String cou_tid);
	//public List<Grade> findGradesBy()

	//public 
	
	//public List<Coursearrange> findAllCourseArranges();
	//列表查询
	public List<Grade> findGrades();
	public void updataGradeByID(String id, String grade, String note);
	

}
