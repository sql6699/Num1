package com.test.dao;

import java.util.List;

import com.test.pojo.Course;
import com.test.pojo.Student;

public interface CourseDao {

	public Course getCourse(String co_id,String co_name,int co_period,int co_credits,String co_type,String co_term);
	
	public List findAllCourse();
	
	//public Student findStudentByid(String st_id);
	public Course findCourseByid(String co_id);
}
 