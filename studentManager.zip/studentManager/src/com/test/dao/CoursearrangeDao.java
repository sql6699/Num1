package com.test.dao;

import java.util.List;

import com.test.pojo.Coursearrange;
import com.test.pojo.Student;

public interface CoursearrangeDao {
	public List<Coursearrange> findCoursearranges(String cou_coid,String cou_clid);
//public Student findStudentByid(String st_id);
	public Coursearrange findarrangeByid(String cou_id);
	
	public List<Coursearrange> findAllCourseArrange(String cou_id, String cou_coid, String cou_clid,String cou_tid);
	
	public List<Coursearrange> findAllCourseArranges();
	//addCoursearrange(coursearrange)
	public void addCoursearrange(Coursearrange coursearrange);
	
	public void updateCourseArrange(Coursearrange coursearrange);
	
	//public List<Coursearrange> findArrange(String arrangeNo, String courseNo, String classNo,String teacherNo);
	
	public int deleteArrange(String cou_id);
}
