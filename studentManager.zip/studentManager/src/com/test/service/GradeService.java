package com.test.service;

import java.util.List;

import com.test.pojo.Coursearrange;
import com.test.pojo.Grade;

public interface GradeService {

	//public void addGrade(Grade grade);
	public void addGrade(Grade grade);
	//public void addGrade(String id,String grade,String note);
	public List findGrades(List<Coursearrange> arrange);
	public List<Grade> findGrades();
	public void updataGradeByID(String id, String grade, String note);
	
}
