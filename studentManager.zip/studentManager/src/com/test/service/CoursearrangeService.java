package com.test.service;

import java.util.List;

import com.test.pojo.Coursearrange;

public interface CoursearrangeService {

	public List<Coursearrange> findCoursearranges(String cou_coid,String cou_clid);
	
	public Coursearrange findarrangeByid(String cou_id);
	
	public List<Coursearrange> findAllCourseArrange(String cou_id, String cou_coid, String cou_clid,String cou_tid);
	public List<Coursearrange> findAllCourseArranges();
	
	public void addCoursearrange(Coursearrange coursearrange);
	
	public void updateCourseArrange(Coursearrange coursearrange);
	
	public int deleteArrange(String cou_id);

}
