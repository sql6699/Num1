package com.test.service.impl;

import java.util.List;

import com.test.dao.ClasstabDao;
import com.test.dao.impl.ClasstabDaoImpl;
import com.test.pojo.Classtab;
import com.test.service.ClasstabService;

public class ClasstabServiceImpl implements ClasstabService {

	//降低耦合
	private ClasstabDao classtabDao = new ClasstabDaoImpl();
	
	public void addclass(Classtab classtab) {
		classtabDao.addclass(classtab);
	}

	public void deleteclass(int cl_id) {
		classtabDao.deleteclass(cl_id);
	}

	public int updateclass(Classtab classtab) {
		return classtabDao.updateclass(classtab);
	}

	// ***********列表查询全部课程信息*************
	public List queryAllClasstab() {
		return classtabDao.queryAllClasstab();
	}

	// ***********根据班级编号查询课程信息*************
	public Classtab queryClasstab(int cl_id) {
		return classtabDao.queryClasstab(cl_id);
	}

}
