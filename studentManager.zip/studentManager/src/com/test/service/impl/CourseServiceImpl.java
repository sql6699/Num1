package com.test.service.impl;

import java.util.List;

import com.test.dao.CourseDao;
import com.test.dao.impl.CourseDaoImpl;
import com.test.pojo.Course;
import com.test.service.CourseService;

public class CourseServiceImpl implements CourseService{
	CourseDao courseDao = new CourseDaoImpl();
	public Course getCourse(String co_id, String co_name, int co_period, int co_credits, String co_type,
			String co_term) {
		// TODO Auto-generated method stub
		return null;
	}

	public List findAllCourse() {
		// TODO Auto-generated method stub
		return courseDao.findAllCourse();
	}

	//ClasstabDao classtabDao = new ClasstabDaoImpl();
}
