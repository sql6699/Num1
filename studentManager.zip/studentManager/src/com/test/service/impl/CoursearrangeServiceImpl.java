package com.test.service.impl;

import java.util.List;

import com.test.dao.CoursearrangeDao;
import com.test.dao.impl.CoursearrangeDaoImpl;
import com.test.pojo.Admin;
import com.test.pojo.Coursearrange;
import com.test.service.CoursearrangeService;

public class CoursearrangeServiceImpl implements CoursearrangeService{
	CoursearrangeDao coursearrangeDao = new CoursearrangeDaoImpl();

	public List<Coursearrange> findCoursearranges(String cou_coid,
			String cou_clid) {
		// TODO Auto-generated method stub
		return coursearrangeDao.findCoursearranges(cou_coid, cou_clid);
	}

	public Coursearrange findarrangeByid(String cou_id){
		return coursearrangeDao.findarrangeByid(cou_id);
	}

	public List<Coursearrange> findAllCourseArrange(String cou_id, String cou_coid, String cou_clid,String cou_tid) {
		// TODO Auto-generated method stub
		return coursearrangeDao.findAllCourseArrange(cou_id, cou_coid, cou_clid, cou_tid);
	}
	
	/**
	 * public Admin findAdminByLoginName(String ad_logname) {
		return adminDao.findAdminByLoginName(ad_logname);
	}

	 */
	public List<Coursearrange> findAllCourseArranges(){
		return coursearrangeDao.findAllCourseArranges();
		
	}

	public void addCoursearrange(Coursearrange coursearrange) {
		// TODO Auto-generated method stub
		coursearrangeDao.addCoursearrange(coursearrange);
		
	}

	public void updateCourseArrange(Coursearrange coursearrange) {
		// TODO Auto-generated method stub
		coursearrangeDao.updateCourseArrange(coursearrange);
		
	}

	public int deleteArrange(String cou_id) {
		// TODO Auto-generated method stub
		return coursearrangeDao.deleteArrange(cou_id);
	}
	
	/**
	 * public int deleteCourseByCoursearrangeNo(String arrangeNo) {
		return coursearrangedao.deleteCourseByCoursearrangeNo(arrangeNo);
	}
	 */
}
