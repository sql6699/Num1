package com.test.service.impl;

import java.util.List;

import com.test.dao.AdminDao;
import com.test.dao.impl.AdminDaoImpl;
import com.test.pojo.Admin;
import com.test.service.AdminService;

public class AdminServiceImpl implements AdminService {

	AdminDao adminDao = new AdminDaoImpl();
	
	public void addAdmin(Admin admin) {
		adminDao.addAdmin(admin);
	}

	public Admin getAdmin(String ad_logname, String ad_pwd) {
		return adminDao.getAdmin(ad_logname, ad_pwd);
	}

	public List findAllAdmin() {
		return adminDao.findAllAdmin();
	}

	public List findAdmin(String ad_logname, String ad_name, String ad_pwd) {
		return adminDao.findAdmin(ad_logname, ad_name, ad_pwd);
	}

	public void updateAdmin(Admin admin) {
		adminDao.updateAdmin(admin);
	}

	public Admin findAdminByLoginName(String ad_logname) {
		return adminDao.findAdminByLoginName(ad_logname);
	}

	public void deleteAdminByLoginName(String ad_logname) {
		adminDao.deleteAdminByLoginName(ad_logname);
	}

}
