package com.test.service.impl;

import java.util.List;

import com.test.dao.GradeDao;
import com.test.dao.impl.GradeDaoImpl;
import com.test.pojo.Coursearrange;
import com.test.pojo.Grade;
import com.test.service.GradeService;

public class GradeServiceImpl implements GradeService{
	GradeDao gradeDao = new GradeDaoImpl();
/*
	public void addGrade(Grade grade) {
		// TODO Auto-generated method stub
		
	}
*/
	
	public List findGrades(List<Coursearrange> arrange) {
		// TODO Auto-generated method stub
		return gradeDao.findGrades(arrange);
	}

	public List<Grade> findGrades() {
		// TODO Auto-generated method stub
		return gradeDao.findGrades();
	}

	public void addGrade(Grade grade) {
		// TODO Auto-generated method stub
		gradeDao.addGrade(grade);
		
	}

	public void updataGradeByID(String id, String grade, String note) {
		// TODO Auto-generated method stub
		gradeDao.updataGradeByID(id, grade, note);
		
	}

}
