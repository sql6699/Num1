package com.test.service.impl;

import com.test.dao.StudentDao;
import com.test.dao.impl.StudentDaoImpl;
import com.test.pojo.Student;
import com.test.service.StudentService;

public class StudentServiceImpl implements StudentService{
	StudentDao studentDao = new StudentDaoImpl();

	public Student findStudentByid(String st_id) {
		// TODO Auto-generated method stub
		return studentDao.findStudentByid(st_id);
	}

	public Student getStudent(String st_id, String st_pwd) {
		// TODO Auto-generated method stub
		return studentDao.getStudent(st_id, st_pwd);
	}
	
	
	//return adminDao.findAdminByLoginName(ad_logname)

}
