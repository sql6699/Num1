package com.test.service.impl;

import java.util.List;

import com.test.dao.StudentDao;
import com.test.dao.TeacherDao;
import com.test.dao.impl.StudentDaoImpl;
import com.test.dao.impl.TeacherDaoImpl;
import com.test.pojo.Student;
import com.test.pojo.Teacher;
import com.test.service.TeacherService;

public class TeacherServiceImpl implements TeacherService{
	TeacherDao teacherDao = new TeacherDaoImpl();

	public Teacher findTeacherByid(String te_id) {
		// TODO Auto-generated method stub
		return teacherDao.findTeacherByid(te_id);
	}

	public List findAllTeacher() {
		// TODO Auto-generated method stub
		return teacherDao.findAllTeacher();
	}
	
	
	public Teacher getTeacher(String te_id,String te_pwd) {
		return teacherDao.getTeacher(te_id, te_pwd);
	}
	
	/**
	 * StudentDao studentDao = new StudentDaoImpl();

	public Student findStudentByid(String st_id) {
		// TODO Auto-generated method stub
		return studentDao.findStudentByid(st_id);
	}
	
	
	 */
}
