package com.test.service;

import java.util.List;

import com.test.pojo.Course;

public interface CourseService {
public Course getCourse(String co_id,String co_name,int co_period,int co_credits,String co_type,String co_term);
	
	public List findAllCourse();

}
