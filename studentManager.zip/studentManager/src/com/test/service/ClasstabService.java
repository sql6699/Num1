package com.test.service;

import java.util.List;

import com.test.pojo.Classtab;

/*Service层叫服务层，被称为服务，
 *粗略的理解就是对一个或多个DAO进行的再次封装，封装成一个服务，
 *所以这里也就不会是一个原子操作了，需要事物控制。
 **/

public interface ClasstabService {
	
	void addclass(Classtab classtab);	// ***********添加课程信息*************
	void deleteclass(int cl_id);		// ***********删除课程信息*************
	int updateclass(Classtab classtab);	// ***********修改课程信息*************
	List queryAllClasstab();			// ********列表查询全部课程信息**********
	Classtab queryClasstab(int cl_id);	// *******根据班级编号查询课程信息********
	
}
