package com.test.service;

import java.util.List;

import com.test.pojo.Teacher;

public interface TeacherService {

	public Teacher findTeacherByid(String te_id);
	public List findAllTeacher();
	
	public Teacher getTeacher(String te_id,String te_pwd);
}
