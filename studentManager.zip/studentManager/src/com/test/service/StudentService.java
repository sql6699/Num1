package com.test.service;

import com.test.pojo.Student;

public interface StudentService {
	public Student findStudentByid(String st_id);
	public Student getStudent(String st_id, String st_pwd);

}
