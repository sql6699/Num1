package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Student;
import com.test.service.ClasstabService;
import com.test.service.StudentService;
import com.test.service.impl.ClasstabServiceImpl;
import com.test.service.impl.StudentServiceImpl;

public class showStudentServlet extends HttpServlet {

	private StudentService studentService = new StudentServiceImpl();
	private ClasstabService classtabService = new ClasstabServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String st_id = req.getParameter("st_id");
		String st_name = req.getParameter("st_name");
		String st_pwd = req.getParameter("st_pwd");
		String st_tel = req.getParameter("st_tel");
		String st_adress = req.getParameter("st_adress");
		String st_email = req.getParameter("st_email");
		String st_classid = req.getParameter("st_classid");
		
		//1、当前要修改的课程安排findStudentBySt_id(st_id);
		//CourseArrange courseArrangeObj = courseArrangeService.queryCourseArrange(cou_id);
		
		Student student = studentService.findStudentByid(st_id);
		req.setAttribute("student", student);
		
		List classtab = classtabService.queryAllClasstab();
		req.setAttribute("classtab", classtab);//classtab
		
		req.getRequestDispatcher("/base/studentShow.jsp").forward(req, resp);
	}

}
