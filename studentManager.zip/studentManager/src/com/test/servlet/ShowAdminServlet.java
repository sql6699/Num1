package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Admin;
import com.test.service.AdminService;
import com.test.service.impl.AdminServiceImpl;

public class ShowAdminServlet extends HttpServlet {

	private AdminService adminService = new AdminServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String ad_logname = req.getParameter("ad_logname");
		Admin admin = adminService.findAdminByLoginName(ad_logname); 
		
		req.setAttribute("admin", admin);
		req.getRequestDispatcher("/base/adminShow.jsp").forward(req, resp);
		
		return ;
	}
	
	
	
}
