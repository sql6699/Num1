package com.test.servlet;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Coursearrange;
import com.test.pojo.Grade;
import com.test.service.ClasstabService;
import com.test.service.CourseService;
import com.test.service.CoursearrangeService;
import com.test.service.GradeService;
import com.test.service.StudentService;
import com.test.service.impl.ClasstabServiceImpl;
import com.test.service.impl.CourseServiceImpl;
import com.test.service.impl.CoursearrangeServiceImpl;
import com.test.service.impl.GradeServiceImpl;
import com.test.service.impl.StudentServiceImpl;

public class GradeServlet extends BaseServlet{
	
	
	ClasstabService clsService = new ClasstabServiceImpl();
	CourseService courseService = new CourseServiceImpl();
	GradeService gradeService = new GradeServiceImpl();
	StudentService studentService = new StudentServiceImpl();
	
	CoursearrangeService coursearrangeService = new CoursearrangeServiceImpl();
	
	
	//显示  ok
	public List CheckGradeServlet(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		List classList = clsService.queryAllClasstab();
		request.setAttribute("classList", classList);
		
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		
		List gradeList = gradeService.findGrades();
		 
		request.setAttribute("gradeList", gradeList);
		
		request.getRequestDispatcher("/grade/submitGrade.jsp").forward(request, response);
		
		System.out.println(classList);
		System.out.println(courseList);
		System.out.println(gradeList);
		return null;
	
		
	}

	
	//查询
	public String queryGradeby(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String courseNo = request.getParameter("courseNo");
		String classNo = request.getParameter("classNo");
	
		//通过课程号和班级号获得课程安排编号
		//classNo
		//List gradeList = cou
		List<Coursearrange> arrange = coursearrangeService.findCoursearranges(courseNo, classNo);
		
		List gradeList = gradeService.findGrades(arrange);
		request.setAttribute("gradeList", gradeList);
		
		List classList = clsService.queryAllClasstab();
		request.setAttribute("classList", classList);
		
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		
		request.getRequestDispatcher("/grade/submitGrade.jsp").forward(request, response);
		
		System.out.println(classList);
		System.out.println(courseList);
		System.out.println(gradeList);
		
		return null;
		
	}
	
	//录入
	public List addGrade(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String ids = request.getParameter("ids");
		String scores = request.getParameter("scores");
		String remarks = request.getParameter("remarks");
		String courseNo = request.getParameter("courseNo");
		String classNo = request.getParameter("classNo");
		
		String[] arr_id = ids.split(",");
		String[] arr_socre = scores.split(",");
		String[] arr_remark = remarks.split(",");
		
		if (arr_id.length == arr_remark.length && arr_remark.length == arr_socre.length) {
			for (int i = 0; i < arr_id.length; i++) {
				gradeService.updataGradeByID(arr_id[i],arr_socre[i],arr_remark[i]);
			}
		}
		
		List classList = clsService.queryAllClasstab();
		request.setAttribute("classList", classList);
		
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		
		List gradeList = gradeService.findGrades();
		request.setAttribute("gradeList", gradeList);
		//request.getRequestDispatcher("GradeServlet?method=CheckGradeServlet").forward(request, response);
		request.getRequestDispatcher("/grade/submitGrade.jsp").forward(request, response);
		
		return null;
	}
	
}
