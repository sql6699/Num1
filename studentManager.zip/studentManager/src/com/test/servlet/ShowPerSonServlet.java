package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.pojo.Admin;
import com.test.pojo.Student;
import com.test.pojo.Teacher;
import com.test.service.AdminService;
import com.test.service.ClasstabService;
import com.test.service.StudentService;
import com.test.service.TeacherService;
import com.test.service.impl.AdminServiceImpl;
import com.test.service.impl.ClasstabServiceImpl;
import com.test.service.impl.StudentServiceImpl;
import com.test.service.impl.TeacherServiceImpl;

public class ShowPerSonServlet extends HttpServlet{
	
	private AdminService adminService = new AdminServiceImpl();
	private StudentService studentService = new StudentServiceImpl();
	private TeacherService teacherService = new TeacherServiceImpl();
	private ClasstabService classtabService = new ClasstabServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = req.getSession(false);
		Integer userType = (Integer) session.getAttribute("userType");
		String studentNo = (String) session.getAttribute("s1");
		String adminName = (String) session.getAttribute("s2");
		String teacherid = (String)session.getAttribute("s3");
		
		System.out.println(userType);
		System.out.println(adminName);
		
		if(userType==0){//findStudentByStudentNo(studentNo);
			
			/**
			 * Admin admin = adminService.findAdminByLoginName(ad_logname); 
		
		req.setAttribute("admin", admin);
			 */
			Admin admin = adminService.findAdminByLoginName(adminName);
			
			System.out.println(admin.toString()+"");
			req.setAttribute("admin", admin);	
			req.getRequestDispatcher("person/adminShow.jsp").forward(req, resp);
		}else if(userType==1){
			Teacher teacher = teacherService.findTeacherByid(teacherid);
			System.err.println(teacherid.toString()+"");
			req.setAttribute("teacher", teacher);
			req.getRequestDispatcher("person/teacherShow.jsp").forward(req, resp);
		}else {
			Student student = studentService.findStudentByid(studentNo);
			List classtab = classtabService.queryAllClasstab();
			req.setAttribute("classtab", classtab);//classtab
			req.setAttribute("student", student);
			
			System.out.println(studentNo);
			
			System.out.println(student);
			System.out.println(classtab);
			req.getRequestDispatcher("person/studentShow.jsp").forward(req, resp);
		}
		
		return;
	}

}
