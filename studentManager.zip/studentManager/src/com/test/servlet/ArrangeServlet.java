package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Coursearrange;
import com.test.service.ClasstabService;
import com.test.service.CourseService;
import com.test.service.CoursearrangeService;
import com.test.service.StudentService;
import com.test.service.TeacherService;
import com.test.service.impl.ClasstabServiceImpl;
import com.test.service.impl.CourseServiceImpl;
import com.test.service.impl.CoursearrangeServiceImpl;
import com.test.service.impl.StudentServiceImpl;
import com.test.service.impl.TeacherServiceImpl;

public class ArrangeServlet extends BaseServlet{
	private StudentService studentService = new StudentServiceImpl();
	private TeacherService teacherService = new TeacherServiceImpl();
	private ClasstabService classtabService = new ClasstabServiceImpl();
	private CourseService courseService = new CourseServiceImpl();
	private CoursearrangeService coursearrangeService = new CoursearrangeServiceImpl();
	
	
	
	public List CheckArrangeServlet(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List teacherList = teacherService.findAllTeacher();
		request.setAttribute("teacherList", teacherList);
		
		List classList = classtabService.queryAllClasstab();
		request.setAttribute("classList", classList);
		
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);

		//List list = coursearrangeservice.findAllCourseArranges();
		List arrangeList = coursearrangeService.findAllCourseArranges();
		request.setAttribute("arrangeList", arrangeList);
		
		request.getRequestDispatcher("/arrange/arrangeList.jsp").forward(request, response);
		
		System.out.println(arrangeList);
		System.out.println(teacherList);
		System.out.println(classList);
		System.out.println(courseList);
		
		
		return null;
	}
	
	public String CheckArrange(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String arrangeNo = request.getParameter("arrangeNo");
		String courseNo = request.getParameter("courseNo");
		String classNo = request.getParameter("classNo");
		String teacherNo = request.getParameter("teacherNo");
		List<Coursearrange> arrangeList = coursearrangeService.findAllCourseArrange(arrangeNo, courseNo, classNo, teacherNo);
		
		List tescherList = teacherService.findAllTeacher();
		request.setAttribute("tescherList", tescherList);
		List classtList = classtabService.queryAllClasstab();
		request.setAttribute("classtList", classtList);
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		
		request.setAttribute("arrangeList", arrangeList);
		request.getRequestDispatcher("/arrange/arrangeList.jsp").forward(request, response);
		return null;
		
	}	
	
	
	/**
	 * 	public String CheckArrange(HttpServletRequest request,HttpServletResponse response) throws 
			ServletException, IOException {

			List tescherList = teacherService.findAllTeacher();
			request.setAttribute("tescherList", tescherList);
			List classtList = classService.findAllClasstbl();
			request.setAttribute("classtList", classtList);
			List courseList = courseService.findAllCourse();
			request.setAttribute("courseList", courseList);
			
			request.setAttribute("arrangeList", arrangeList);
			request.getRequestDispatcher("/arrange/arrangeList.jsp").forward(request, response);
			
			return null;
			
		}
	
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	
	//添加
	public List Addarrange(HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		Coursearrange coursearrange = new Coursearrange();
		
		coursearrange.setCou_id(request.getParameter("arrangeNo"));
		coursearrange.setCou_coid(request.getParameter("courseNo"));
		/*
		String classNo = request.getParameter("classNo");
		String teacherNo = request.getParameter("teacherNo");
		int a=Integer.parseInt(classNo);
		int b=Integer.parseInt(teacherNo);
		*/
		coursearrange.setCou_clid(request.getParameter("classNo"));
		coursearrange.setCou_tid(request.getParameter("teacherNo"));
		coursearrange.setCou_room(request.getParameter("studyRoom"));
		
		coursearrangeService.addCoursearrange(coursearrange);
		
		
		
		List teacherList = teacherService.findAllTeacher();
		request.setAttribute("teacherList", teacherList);
		
		List classList = classtabService.queryAllClasstab();
		request.setAttribute("classList", classList);
		
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		
		/*
		List arrangeList = coursearrangeService.findAllcourseArrange();
		request.setAttribute("arrangeList", arrangeList);
		
		*/
		List arrangeList = coursearrangeService.findAllCourseArranges();
		request.setAttribute("coursearrange", coursearrange);
		
		request.getRequestDispatcher("/arrange/arrangeList.jsp").forward(request,response);
		
		return null;
		
	}
	
	//由id查
	public String Showarrange(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String arrangeNo = request.getParameter("arrangeNo");
		Coursearrange coursearrange = coursearrangeService.findarrangeByid(arrangeNo);
		request.setAttribute("coursearrange", coursearrange);
		request.getRequestDispatcher("/arrange/arrangeShow.jsp").forward(request,response);
		return null;
		
	}
	//修改
	public String updateArrange(HttpServletRequest request,HttpServletResponse response) throws Exception{
        Coursearrange coursearrange = new Coursearrange();
		
		coursearrange.setCou_id(request.getParameter("arrangeNo"));
		coursearrange.setCou_coid(request.getParameter("courseNo"));
		coursearrange.setCou_clid(request.getParameter("classNo"));
		coursearrange.setCou_tid(request.getParameter("teacherNo"));
		coursearrange.setCou_room(request.getParameter("studyRoom"));
		/*
		coursearrangeService.updateCourseArrange(coursearrange);
		List arrangeList = coursearrangeService.findAllcourseArrange();
		request.setAttribute("arrangeList", arrangeList);
		*/
		
		coursearrangeService.updateCourseArrange(coursearrange);
		
	//	List teacherList = teacherService.findAllTeacher();
	//	request.setAttribute("teacherList", teacherList);
		
	//	List classList = classtabService.queryAllClasstab();
	//	request.setAttribute("classList", classList);
		
	//	List courseList = courseService.findAllCourse();
	//	request.setAttribute("courseList", courseList);
		
		/*
		List arrangeList = coursearrangeService.findAllcourseArrange();
		request.setAttribute("arrangeList", arrangeList);
		
		*/
	//	List arrangeList = coursearrangeService.findAllCourseArranges();
	//	request.setAttribute("arrangeList", arrangeList);
		
		request.setAttribute("coursearrange", coursearrange);
		request.getRequestDispatcher("ArrangeServlet?method=CheckArrangeServlet").forward(request, response);
		
		return null;
		
	}
	
	//删除
	public String deleteArrange(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String arrangeNo = request.getParameter("arrangeNo");
		
		/*
		coursearrangeService.deleteArrange(arrangeNo);
		List arrangeList = coursearrangeService.findAllcourseArrange();
		request.setAttribute("arrangeList", arrangeList);
		*/
		coursearrangeService.deleteArrange(arrangeNo);
		List arrangeList = coursearrangeService.findAllCourseArranges();
		request.setAttribute("arrangeList", arrangeList);
		
		request.getRequestDispatcher("/arrange/arrangeList.jsp").forward(request, response);
		return null;
		
	}
	
	//条件查询
	public String queryArrange(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String arrangeNo = request.getParameter("arrangeNo");
		String courseNo = request.getParameter("courseNo");
		String classNo = request.getParameter("classNo");
		String teacherNo = request.getParameter("teacherNo");
//		String studyRoom = request.getParameter("studyRoom");
		
		List arrangeList = coursearrangeService.findAllCourseArrange(arrangeNo, courseNo, classNo, teacherNo);
		request.setAttribute("arrangeList", arrangeList);
		
		List teacherList = teacherService.findAllTeacher();
		request.setAttribute("teacherList", teacherList);
		
		List classList = classtabService.queryAllClasstab();
		request.setAttribute("classList", classList);
		
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		
		request.getRequestDispatcher("/arrange/arrangeList.jsp").forward(request, response);

		
		return null;
		
	}
	
	
	
	//进入添加界面
	/**
	 * 
	 * 进入添加课程安排管理界面
	 */
	public List toAddArrangeServlet(HttpServletRequest request, HttpServletResponse response) throws Exception {

		List tescherList = teacherService.findAllTeacher();
		request.setAttribute("tescherList", tescherList);
		// System.out.println(tescherList);classService.findAllClasstbl();

		List classtList = classtabService.queryAllClasstab();
		request.setAttribute("classtList", classtList);
		// System.out.println(classtList);

		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		// System.out.println(courseList);

		request.getRequestDispatcher("/arrange/addArrange.jsp").forward(request, response);

		return null;
	}


	//进入查看页面
	public String ShowArrange(HttpServletRequest request,HttpServletResponse response) throws Exception {
		String arrangeNo = request.getParameter("arrangeNo");
		String courseNo = request.getParameter("courseNo");
		String classNo = request.getParameter("classNo");
		String teacherNo = request.getParameter("teacherNo");
		String studyRoom = request.getParameter("studyRoom");
		Coursearrange coursearrange = coursearrangeService.findarrangeByid(arrangeNo);
		request.setAttribute("coursearrange", coursearrange);
		//List<ClassTbl> classtbls = clsService.getAllClasses();
		List courseList = courseService.findAllCourse();
		request.setAttribute("courseList", courseList);
		List tescherList = teacherService.findAllTeacher();
		request.setAttribute("tescherList", tescherList);
		// System.out.println(tescherList);classService.findAllClasstbl();

		List classtList = classtabService.queryAllClasstab();
		request.setAttribute("classtList", classtList);
		// System.out.println(classtList);
		
		
		request.getRequestDispatcher("/arrange/arrangeShow.jsp").forward(request,response);
		return null;
		
	}
	
	
	
	
	
	
}
