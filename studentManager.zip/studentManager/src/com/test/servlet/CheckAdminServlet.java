package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Admin;
import com.test.service.AdminService;
import com.test.service.impl.AdminServiceImpl;

public class CheckAdminServlet extends HttpServlet {

	private AdminService adminService = new AdminServiceImpl();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String ad_logname = req.getParameter("ad_logname");
		String ad_name = req.getParameter("ad_name");
		String ad_pwd = req.getParameter("ad_pwd");
		
		List<Admin> list = adminService.findAdmin(ad_logname,ad_name,ad_pwd);

		req.setAttribute("list", list);
		req.getRequestDispatcher("/base/adminList.jsp").forward(req, resp);

	}

}
