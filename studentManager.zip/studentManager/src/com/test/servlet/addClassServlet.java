package com.test.servlet;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Classtab;
import com.test.service.ClasstabService;
import com.test.service.impl.ClasstabServiceImpl;

public class addClassServlet {
	
	private ClasstabService classtabService = new ClasstabServiceImpl();
	
	public String classtabAdd(HttpServletRequest request,
			HttpServletResponse response) throws Exception{
		Classtab classtab = new Classtab();
		//String 转换成 Int
		classtab.setCl_id(Integer.parseInt(request.getParameter("cl_id")));
		classtab.setCl_name(request.getParameter("cl_name"));
		classtab.setCl_belong(request.getParameter("cl_belong"));
		
		classtabService.addclass(classtab);
		List classtabList = classtabService.queryAllClasstab();
		request.setAttribute("classtabList", classtabList);
		request.getRequestDispatcher("/base/classList.jsp").forward(request, response);
		
		return null;
	}
	
}
