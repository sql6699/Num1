package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Admin;
import com.test.pojo.Classtab;
import com.test.service.ClasstabService;
import com.test.service.impl.ClasstabServiceImpl;

public class ClassServlet extends BaseServlet{

	private ClasstabService classtabService = new ClasstabServiceImpl();
	private Classtab classtab = new Classtab();
	
	
	public List ShowClass(HttpServletRequest req,HttpServletResponse resp) throws Exception {
	
		List classtab = classtabService.queryAllClasstab();
		req.setAttribute("classtab", classtab);
		req.getRequestDispatcher("/base/classList.jsp").forward(req, resp);
		
		return null;
	}
	
	/*用于班级信息列表显示*/
	/*1.先从前台获取到相应的位置
	 *2.从数据库中获取到全部值存入List集合
	 *3.存放到request请求中，留着传值
	 * */
	/*第一次用到：adminList中的《班级信息维护》*/
	public String CheckClass(HttpServletRequest request,HttpServletResponse response) throws 
	ServletException, IOException {
		
//		String cl_id = request.getParameter("cl_id");
//		String cl_name = request.getParameter("cl_name");
//		String cl_belong = request.getParameter("cl_belong");
		
		List<Classtab> classtabList = classtabService.queryAllClasstab();
		request.setAttribute("classtabList", classtabList);
		request.getRequestDispatcher("/base/classList.jsp").forward(request, response);
		
		return null;
	}
	
	
	public String DeleteClass(HttpServletRequest req,HttpServletResponse resp) throws 
	ServletException, IOException {
		
		String cl_id = req.getParameter("cl_id");
//		String cl_name = req.getParameter("cl_name");
//		String cl_belong = req.getParameter("cl_belong");
		
//		classtab.setCl_id(Integer.parseInt(cl_id));
		classtabService.deleteclass(Integer.parseInt(cl_id));
//		req.setAttribute("classtab", classtab);
//		System.out.println(classtab);
//		req.setAttribute("aa", "aaa");
		
		req.getRequestDispatcher("/ClassServlet?method=CheckClass").forward(req, resp);
		
		return null;
	}
	
	/*//a标签里的单击事件都是get提交
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String ad_logname = req.getParameter("ad_logname");
		Admin admin = new Admin();
		admin.setAd_logname(ad_logname);
		adminService.deleteAdminByLoginName(ad_logname);
		req.setAttribute("admin", admin);
		System.out.println(admin);
		req.getRequestDispatcher("listAllAdminServlet").forward(req, resp);
		
	}*/
	
}
