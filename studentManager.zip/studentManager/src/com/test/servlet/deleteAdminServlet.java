package com.test.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Admin;
import com.test.service.AdminService;
import com.test.service.impl.AdminServiceImpl;

public class deleteAdminServlet extends HttpServlet{
	
	private AdminService adminService = new AdminServiceImpl();

	//a标签里的单击事件都是get提交
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String ad_logname = req.getParameter("ad_logname");
		Admin admin = new Admin();
		admin.setAd_logname(ad_logname);
		adminService.deleteAdminByLoginName(ad_logname);
		req.setAttribute("admin", admin);
		System.out.println(admin);
		req.getRequestDispatcher("listAllAdminServlet").forward(req, resp);
		
	}
	
	
	
	
}
