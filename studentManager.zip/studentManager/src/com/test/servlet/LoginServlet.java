package com.test.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.pojo.Admin;
import com.test.pojo.Student;
import com.test.pojo.Teacher;
//import com.test.pojo.Student;
//import com.test.pojo.Teacher;
import com.test.pojo.User;
import com.test.service.AdminService;
import com.test.service.StudentService;
import com.test.service.TeacherService;
//import com.test.service.TeacherService;
import com.test.service.impl.AdminServiceImpl;
//import com.test.service.impl.TeacherServiceImpl;
import com.test.service.impl.StudentServiceImpl;
import com.test.service.impl.TeacherServiceImpl;

public class LoginServlet extends HttpServlet {

	AdminService adminService = new AdminServiceImpl();
	StudentService studentService = new StudentServiceImpl();
	TeacherService teacherService = new TeacherServiceImpl();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out = resp.getWriter();

		resp.setContentType("text/html;charset=utf-8");
		String logname = req.getParameter("loginName");
		
		String pwd = req.getParameter("password");

		// 管理员admin使用loginName登录
		Admin admin = adminService.getAdmin(logname, pwd);
		// 学生student使用studentNo登录
		Student student = studentService.getStudent(logname, pwd);
		// 老师teacher使用teacherNo登录
		Teacher teacher = teacherService.getTeacher(logname, pwd);
		
		User user = new User();
		int userType = -1;
		if (student != null) {
			//int i = student.getSt_id();
			int i = student.getSt_id();
			String s=String.valueOf(i);
			req.getSession().setAttribute("studentid", s);
			userType = 2;
			user.setUserType(2);
			user.setName(student.getSt_name());
			//String s=String.valueOf(i);
			//int i = student.getSt_id();
			//String s=String.valueOf(i);
			
			//********
			req.getSession().setAttribute("userType", userType);
			req.getSession().setAttribute("user", user);
			System.out.println("LoginServlet中的user：" + user);
			req.getRequestDispatcher("/index.jsp").forward(req,
					resp);
		} else if (teacher != null) {
			int i = teacher.getTe_id();
			String s=String.valueOf(i);
			req.getSession().setAttribute("teacherid", s);
			userType = 1;
			user.setUserType(1);
			user.setName(teacher.getTe_name());
			req.getSession().setAttribute("userType", userType);
			req.getSession().setAttribute("user", user);
			System.out.println("LoginServlet中的user：" + user);
			req.getRequestDispatcher("/index.jsp").forward(req,
					resp);
		} else if (admin != null) {
			req.getSession().setAttribute("adminname", admin.getAd_logname());
			userType = 0;
			user.setUserType(0);
			user.setName(admin.getAd_name());
			//user.setLogname(admin.getAd_logname());
			
			req.getSession().setAttribute("userType", userType);
			req.getSession().setAttribute("user", user);
			System.out.println("LoginServlet中的user：" + user);
			req.getRequestDispatcher("/index.jsp").forward(req,
					resp);
		} else {
			out.println("用户名或密码错误");
			RequestDispatcher dispatcher = req.getRequestDispatcher("/serviceException.jsp");
			dispatcher.forward(req, resp);
		}
		
		return ;

	}

	// <form name="myForm" action="LoginServlet" method="post" >
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(req, resp);
	}

}
