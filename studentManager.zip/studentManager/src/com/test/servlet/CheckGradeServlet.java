package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.pojo.Coursearrange;
import com.test.service.AdminService;
import com.test.service.ClasstabService;
import com.test.service.CourseService;
import com.test.service.CoursearrangeService;
import com.test.service.GradeService;
import com.test.service.impl.AdminServiceImpl;
import com.test.service.impl.ClasstabServiceImpl;
import com.test.service.impl.CourseServiceImpl;
import com.test.service.impl.CoursearrangeServiceImpl;
import com.test.service.impl.GradeServiceImpl;
//AdminService adminService = new AdminServiceImpl();
public class CheckGradeServlet extends HttpServlet{
	ClasstabService clsService = new ClasstabServiceImpl();
	CourseService courseService = new CourseServiceImpl();
	GradeService gradeService = new GradeServiceImpl();
	CoursearrangeService coursearrangeService = new CoursearrangeServiceImpl();
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseNo = req.getParameter("courseNo");
		String classNo = req.getParameter("classNo"); 
		HttpSession session = req.getSession();
		session.setAttribute("courseNo", courseNo);
		session.setAttribute("classNo", classNo);
		
		
		//findCoursearranges(courseNo, a);
		List<Coursearrange> arrange = coursearrangeService.findCoursearranges(courseNo, classNo);
		List list = gradeService.findGrades(arrange);
		
		req.setAttribute("list", list);
		List classTbls = clsService.queryAllClasstab();
		List courses = courseService.findAllCourse();
		
		req.setAttribute("classTbls", classTbls);
		req.setAttribute("courses", courses);
		
		System.out.println(classTbls);
		System.out.println(courses);
		System.out.println(list);

		req.getRequestDispatcher("/grade/submitGrade.jsp").forward(req, resp);
		return;	 
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
}
