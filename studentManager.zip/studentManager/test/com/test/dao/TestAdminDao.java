package com.test.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.test.dao.impl.AdminDaoImpl;
import com.test.pojo.Admin;

public class TestAdminDao {

	AdminDao adminDao = new AdminDaoImpl();
	
	//添加管理员
	@Ignore
	public void testAddAdmin() {
		String ad_logname = "帅小伟";
		String ad_name = "shuaixiaowei";
		String ad_pwd = "123456";
		
		Admin admin = new Admin(ad_logname, ad_name, ad_pwd);
		adminDao.addAdmin(admin);
	}
	
	//得到一个管理员信息，进行登录时用
	@Ignore
	public void testGetAdmin() {

		String ad_logname = "帅小伟";
		String ad_pwd = "123456";

		Admin admin = adminDao.getAdmin(ad_logname, ad_pwd);

		assertTrue("帅小伟".equals(admin.getAd_logname()));

		System.out.println(admin);
	}
	
	//查找所有的admini信息
	@Ignore
	public void testFindAllAdmin(){
		List admin = adminDao.findAllAdmin();
		
		System.out.println(admin);
	}
	
	@Ignore
	public void testFindAdmins(){
		String ad_logname = "帅小伟";
		String ad_name = "shuaixiaowei";
		String ad_pwd = "123456";
		List admin = adminDao.findAdmin(ad_logname, ad_name, ad_pwd);
		
		System.out.println(admin);
	}
	
	//根据登录名修改信息
	@Ignore
	public void testUpdateAdmin(){
		String ad_logname = "帅小伟";
		String ad_name = "shuaixiaowei01";
		String ad_pwd = "123456";
		
		Admin admin = new Admin(ad_logname, ad_name, ad_pwd);
		adminDao.updateAdmin(admin);
		System.out.println(admin);
	}
	
	@Ignore
	public void testFindAdminByLoginName(){
		String ad_logname = "帅小伟";
		
		Admin admin = adminDao.findAdminByLoginName(ad_logname);
		System.out.println(admin);
	}
	
	@Ignore
	public void testDeleteAdminByLoginName(){
		String ad_logname = "帅小伟";
		
		adminDao.deleteAdminByLoginName(ad_logname);
	}

}
