package com.test.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.test.dao.impl.CourseDaoImpl;
import com.test.pojo.Course;

public class TestCourseDao {

	CourseDao courseDao = new CourseDaoImpl();
	
	@Test
	public void test() {

		String co_id="t001";			//编号
		String co_name="计算机软件开发";	//名称
		int co_period=10;				//学时
		int co_credits=20;				//学分
		String co_type="软件开发";		//课程类别
		String co_term="三";				//学期
		
		Course course = courseDao.getCourse(co_id, co_name, co_period, co_credits, co_type, co_term);
		
		assertTrue(10==course.getCo_period());
		
	}

}
