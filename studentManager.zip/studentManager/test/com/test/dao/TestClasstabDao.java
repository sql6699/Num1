package com.test.dao;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.test.dao.impl.ClasstabDaoImpl;
import com.test.pojo.Classtab;
import com.test.utils.*;

public class TestClasstabDao {

	ClasstabDao classtabDao = new ClasstabDaoImpl();
	
	@Ignore
	public void testGetClassTab() {
		
		//实际传入一个对象的全部属性进行连接测试
		int cl_id = 2001;
		String cl_name = "计算机（1）班";
		String cl_belong = "数计学院";
		
		//获取传入的一个对象的属性的值，返回一个对象
		Classtab classtab = classtabDao.getClasstab(cl_id, cl_name, cl_belong);
		
		//上面的数值与数据库中的值进行比较
//		assertTrue("计算机学院".equals(classtab.getCl_belong()));
		assertTrue(2001==classtab.getCl_id());
	}
	
	//***************增加班级信息*****************
	@Ignore
	public void testAddclass(){
		
		int cl_id = 2002;
		String cl_name = "计算机（2）班";
		String cl_belong = "数计学院";
		
		Classtab classtab = new Classtab(cl_id,cl_name,cl_belong);
		classtabDao.addclass(classtab);
	}
	
	//***************修改班级信息*****************
	@Ignore
	public void testUpdateclass(){
		
		int cl_id = 2000;
		String cl_name = "计算机（3）班";
		String cl_belong = "数计学院";
		
		Classtab classtab = new Classtab(cl_id,cl_name,cl_belong);
		int result = classtabDao.updateclass(classtab);
		
		assertEquals(result, 1);
	}
	
	//***************删除班级信息*****************
	@Ignore
	public void testDeleteclass(){		
		int cl_id = 1;
		classtabDao.deleteclass(cl_id);
	}
	
	//***************查询全部班级信息*****************
	@Ignore
	public void testqueryAllClasstab(){
		List classtab = classtabDao.queryAllClasstab();
		System.out.println(classtab);
	}
	
	//**************根据编号查询班级信息****************
	@Ignore
	public void testqueryClasstab(){
		int cl_id = 2001;
		System.out.println(classtabDao.queryClasstab(cl_id));
	}
	
}
