package com.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.test.pojo.Classtab;
import com.test.service.impl.ClasstabServiceImpl;

public class TestClasstabService {

	ClasstabService classtabService = new ClasstabServiceImpl();
	
	// ***********添加课程信息*************
	@Ignore
	public void testAddclass() {
		
		int cl_id = 2004;
		String cl_name = "计算机（4）班";
		String cl_belong = "数计学院";
		
		Classtab classtab = new Classtab(cl_id,cl_name,cl_belong);
		classtabService.addclass(classtab);
	}

	// ***********修改课程信息*************
	@Ignore
	public void testUpdateclass(){
		
		int cl_id = 2000;
		String cl_name = "计算机（1）班";
		String cl_belong = "数计学院";
		
		Classtab classtab = new Classtab(cl_id,cl_name,cl_belong);
		int result = classtabService.updateclass(classtab);
		
		assertEquals(result,1);
	}
	
	// ***********删除课程信息*************
	@Ignore
	public void testDeleteclass(){
		int cl_id = 2000;
		classtabService.deleteclass(cl_id);
	}
	
	// ********列表查询全部课程信息**********
	@Ignore
	public void testqueryAllClasstab(){
		List classtab = classtabService.queryAllClasstab();
		System.out.println(classtab);
	}
	
	// *******根据班级编号查询课程信息********
	@Test
	public void testqueryClasstab(){
		int cl_id = 2001;
		System.out.println(classtabService.queryClasstab(cl_id));
	}
	
}
